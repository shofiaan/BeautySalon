﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Index
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Index))
        Me.timerSlide = New System.Windows.Forms.Timer(Me.components)
        Me.iklan = New System.Windows.Forms.ImageList(Me.components)
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.clbday = New System.Windows.Forms.CheckedListBox()
        Me.MonthCalendar1 = New System.Windows.Forms.MonthCalendar()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.numday = New System.Windows.Forms.NumericUpDown()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.cbSpa = New System.Windows.Forms.CheckBox()
        Me.cbMassage = New System.Windows.Forms.CheckBox()
        Me.cmb3 = New System.Windows.Forms.ComboBox()
        Me.cbScrub = New System.Windows.Forms.CheckBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.cbManicure = New System.Windows.Forms.CheckBox()
        Me.cbRebound = New System.Windows.Forms.CheckBox()
        Me.cmb2 = New System.Windows.Forms.ComboBox()
        Me.cbCreambath = New System.Windows.Forms.CheckBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cbLaser = New System.Windows.Forms.CheckBox()
        Me.cbTotok = New System.Windows.Forms.CheckBox()
        Me.cbFacial = New System.Windows.Forms.CheckBox()
        Me.cmb1 = New System.Windows.Forms.ComboBox()
        Me.lblhello = New System.Windows.Forms.Label()
        Me.carttool = New System.Windows.Forms.ToolStrip()
        Me.TsOrder = New System.Windows.Forms.ToolStripButton()
        Me.tbexit = New System.Windows.Forms.ToolStripButton()
        Me.infoorder = New System.Windows.Forms.ToolTip(Me.components)
        Me.btnOrder = New System.Windows.Forms.Button()
        Me.infofix = New System.Windows.Forms.ToolTip(Me.components)
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.lblAll = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.lblTotal = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        CType(Me.numday, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.carttool.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'timerSlide
        '
        Me.timerSlide.Enabled = True
        Me.timerSlide.Interval = 1000
        '
        'iklan
        '
        Me.iklan.ImageStream = CType(resources.GetObject("iklan.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.iklan.TransparentColor = System.Drawing.Color.Transparent
        Me.iklan.Images.SetKeyName(0, "1.jpg")
        Me.iklan.Images.SetKeyName(1, "2.jpg")
        Me.iklan.Images.SetKeyName(2, "3.jpg")
        Me.iklan.Images.SetKeyName(3, "4.jpg")
        Me.iklan.Images.SetKeyName(4, "5.jpg")
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.clbday)
        Me.GroupBox1.Controls.Add(Me.MonthCalendar1)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.numday)
        Me.GroupBox1.Controls.Add(Me.GroupBox5)
        Me.GroupBox1.Controls.Add(Me.GroupBox4)
        Me.GroupBox1.Controls.Add(Me.GroupBox3)
        Me.GroupBox1.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.GroupBox1.Location = New System.Drawing.Point(-9, 3)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(710, 447)
        Me.GroupBox1.TabIndex = 12
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Treatment"
        '
        'clbday
        '
        Me.clbday.FormattingEnabled = True
        Me.clbday.Items.AddRange(New Object() {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"})
        Me.clbday.Location = New System.Drawing.Point(418, 238)
        Me.clbday.Name = "clbday"
        Me.clbday.Size = New System.Drawing.Size(216, 144)
        Me.clbday.TabIndex = 34
        '
        'MonthCalendar1
        '
        Me.MonthCalendar1.BackColor = System.Drawing.Color.White
        Me.MonthCalendar1.Location = New System.Drawing.Point(63, 232)
        Me.MonthCalendar1.Name = "MonthCalendar1"
        Me.MonthCalendar1.TabIndex = 33
        Me.MonthCalendar1.TrailingForeColor = System.Drawing.SystemColors.GradientActiveCaption
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(302, 290)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(100, 17)
        Me.Label7.TabIndex = 32
        Me.Label7.Text = "How Many Day?"
        '
        'numday
        '
        Me.numday.Location = New System.Drawing.Point(318, 310)
        Me.numday.Maximum = New Decimal(New Integer() {7, 0, 0, 0})
        Me.numday.Name = "numday"
        Me.numday.Size = New System.Drawing.Size(56, 25)
        Me.numday.TabIndex = 31
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.Label3)
        Me.GroupBox5.Controls.Add(Me.cbSpa)
        Me.GroupBox5.Controls.Add(Me.cbMassage)
        Me.GroupBox5.Controls.Add(Me.cmb3)
        Me.GroupBox5.Controls.Add(Me.cbScrub)
        Me.GroupBox5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.GroupBox5.Location = New System.Drawing.Point(459, 34)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(200, 178)
        Me.GroupBox5.TabIndex = 20
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Body"
        '
        'cbSpa
        '
        Me.cbSpa.AutoSize = True
        Me.cbSpa.Location = New System.Drawing.Point(42, 78)
        Me.cbSpa.Name = "cbSpa"
        Me.cbSpa.Size = New System.Drawing.Size(49, 22)
        Me.cbSpa.TabIndex = 21
        Me.cbSpa.Text = "Spa"
        Me.cbSpa.UseVisualStyleBackColor = True
        '
        'cbMassage
        '
        Me.cbMassage.AutoSize = True
        Me.cbMassage.Location = New System.Drawing.Point(42, 55)
        Me.cbMassage.Name = "cbMassage"
        Me.cbMassage.Size = New System.Drawing.Size(78, 22)
        Me.cbMassage.TabIndex = 20
        Me.cbMassage.Text = "Massage"
        Me.cbMassage.UseVisualStyleBackColor = True
        '
        'cmb3
        '
        Me.cmb3.FormattingEnabled = True
        Me.cmb3.Items.AddRange(New Object() {"Nature Republic", "The Body Shop", "Ms Glow", "Clarins", "SomeBy Me"})
        Me.cmb3.Location = New System.Drawing.Point(42, 132)
        Me.cmb3.Name = "cmb3"
        Me.cmb3.Size = New System.Drawing.Size(145, 26)
        Me.cmb3.TabIndex = 19
        '
        'cbScrub
        '
        Me.cbScrub.AutoSize = True
        Me.cbScrub.Location = New System.Drawing.Point(42, 32)
        Me.cbScrub.Name = "cbScrub"
        Me.cbScrub.Size = New System.Drawing.Size(89, 22)
        Me.cbScrub.TabIndex = 18
        Me.cbScrub.Text = "Scrubbing"
        Me.cbScrub.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.Label1)
        Me.GroupBox4.Controls.Add(Me.cbManicure)
        Me.GroupBox4.Controls.Add(Me.cbRebound)
        Me.GroupBox4.Controls.Add(Me.cmb2)
        Me.GroupBox4.Controls.Add(Me.cbCreambath)
        Me.GroupBox4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.GroupBox4.Location = New System.Drawing.Point(234, 34)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(204, 178)
        Me.GroupBox4.TabIndex = 19
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Hair"
        '
        'cbManicure
        '
        Me.cbManicure.AutoSize = True
        Me.cbManicure.Location = New System.Drawing.Point(30, 78)
        Me.cbManicure.Name = "cbManicure"
        Me.cbManicure.Size = New System.Drawing.Size(114, 22)
        Me.cbManicure.TabIndex = 20
        Me.cbManicure.Text = "Hair Manicure"
        Me.cbManicure.UseVisualStyleBackColor = True
        '
        'cbRebound
        '
        Me.cbRebound.AutoSize = True
        Me.cbRebound.Location = New System.Drawing.Point(30, 55)
        Me.cbRebound.Name = "cbRebound"
        Me.cbRebound.Size = New System.Drawing.Size(100, 22)
        Me.cbRebound.TabIndex = 19
        Me.cbRebound.Text = "Rebounding"
        Me.cbRebound.UseVisualStyleBackColor = True
        '
        'cmb2
        '
        Me.cmb2.FormattingEnabled = True
        Me.cmb2.Items.AddRange(New Object() {"Nature Republic", "Tresemme", "L'Oreal", "Makarizo", "Shiseido"})
        Me.cmb2.Location = New System.Drawing.Point(30, 132)
        Me.cmb2.Name = "cmb2"
        Me.cmb2.Size = New System.Drawing.Size(138, 26)
        Me.cmb2.TabIndex = 18
        '
        'cbCreambath
        '
        Me.cbCreambath.AutoSize = True
        Me.cbCreambath.Location = New System.Drawing.Point(30, 32)
        Me.cbCreambath.Name = "cbCreambath"
        Me.cbCreambath.Size = New System.Drawing.Size(95, 22)
        Me.cbCreambath.TabIndex = 17
        Me.cbCreambath.Text = "Creambath"
        Me.cbCreambath.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox3.Controls.Add(Me.Label2)
        Me.GroupBox3.Controls.Add(Me.cbLaser)
        Me.GroupBox3.Controls.Add(Me.cbTotok)
        Me.GroupBox3.Controls.Add(Me.cbFacial)
        Me.GroupBox3.Controls.Add(Me.cmb1)
        Me.GroupBox3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.GroupBox3.Location = New System.Drawing.Point(34, 34)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(185, 178)
        Me.GroupBox3.TabIndex = 18
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Face"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(41, 111)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(102, 18)
        Me.Label2.TabIndex = 18
        Me.Label2.Text = "Choose Product"
        '
        'cbLaser
        '
        Me.cbLaser.AutoSize = True
        Me.cbLaser.Location = New System.Drawing.Point(29, 78)
        Me.cbLaser.Name = "cbLaser"
        Me.cbLaser.Size = New System.Drawing.Size(60, 22)
        Me.cbLaser.TabIndex = 17
        Me.cbLaser.Text = "Laser"
        Me.cbLaser.UseVisualStyleBackColor = True
        '
        'cbTotok
        '
        Me.cbTotok.AutoSize = True
        Me.cbTotok.Location = New System.Drawing.Point(29, 55)
        Me.cbTotok.Name = "cbTotok"
        Me.cbTotok.Size = New System.Drawing.Size(61, 22)
        Me.cbTotok.TabIndex = 16
        Me.cbTotok.Text = "Totok"
        Me.cbTotok.UseVisualStyleBackColor = True
        '
        'cbFacial
        '
        Me.cbFacial.AutoSize = True
        Me.cbFacial.Location = New System.Drawing.Point(29, 32)
        Me.cbFacial.Name = "cbFacial"
        Me.cbFacial.Size = New System.Drawing.Size(62, 22)
        Me.cbFacial.TabIndex = 14
        Me.cbFacial.Text = "Facial"
        Me.cbFacial.UseVisualStyleBackColor = True
        '
        'cmb1
        '
        Me.cmb1.FormattingEnabled = True
        Me.cmb1.Items.AddRange(New Object() {"Nature Republic", "MS Glow", "Erha Skin", "Wardah", "Jafra"})
        Me.cmb1.Location = New System.Drawing.Point(29, 132)
        Me.cmb1.Name = "cmb1"
        Me.cmb1.Size = New System.Drawing.Size(130, 26)
        Me.cmb1.TabIndex = 15
        '
        'lblhello
        '
        Me.lblhello.AutoSize = True
        Me.lblhello.BackColor = System.Drawing.Color.Transparent
        Me.lblhello.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblhello.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblhello.Location = New System.Drawing.Point(528, 26)
        Me.lblhello.Name = "lblhello"
        Me.lblhello.Size = New System.Drawing.Size(302, 22)
        Me.lblhello.TabIndex = 0
        Me.lblhello.Text = "Treat Your Body well, dont edit it to much.!"
        '
        'carttool
        '
        Me.carttool.Dock = System.Windows.Forms.DockStyle.None
        Me.carttool.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TsOrder, Me.tbexit})
        Me.carttool.Location = New System.Drawing.Point(15, 9)
        Me.carttool.Name = "carttool"
        Me.carttool.Size = New System.Drawing.Size(58, 25)
        Me.carttool.TabIndex = 18
        Me.carttool.Text = "ToolStrip1"
        '
        'TsOrder
        '
        Me.TsOrder.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.TsOrder.Image = CType(resources.GetObject("TsOrder.Image"), System.Drawing.Image)
        Me.TsOrder.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TsOrder.Name = "TsOrder"
        Me.TsOrder.Size = New System.Drawing.Size(23, 22)
        Me.TsOrder.Text = "Calculate Order"
        Me.TsOrder.ToolTipText = "This ToolBar will calculate your treatment before fixed billing"
        '
        'tbexit
        '
        Me.tbexit.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tbexit.Image = CType(resources.GetObject("tbexit.Image"), System.Drawing.Image)
        Me.tbexit.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tbexit.Name = "tbexit"
        Me.tbexit.Size = New System.Drawing.Size(23, 22)
        Me.tbexit.Text = "Exit"
        '
        'infoorder
        '
        Me.infoorder.ToolTipTitle = "Billing Form"
        '
        'btnOrder
        '
        Me.btnOrder.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnOrder.Font = New System.Drawing.Font("Palatino Linotype", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnOrder.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btnOrder.Location = New System.Drawing.Point(29, 88)
        Me.btnOrder.Name = "btnOrder"
        Me.btnOrder.Size = New System.Drawing.Size(113, 29)
        Me.btnOrder.TabIndex = 19
        Me.btnOrder.Text = "Order"
        Me.infoorder.SetToolTip(Me.btnOrder, "This Button will take you to your Fixed Bill that you have to pay")
        Me.btnOrder.UseVisualStyleBackColor = True
        '
        'infofix
        '
        Me.infofix.ToolTipTitle = "Order Button"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Transparent
        Me.Panel1.Controls.Add(Me.GroupBox1)
        Me.Panel1.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Panel1.Location = New System.Drawing.Point(21, 51)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(704, 432)
        Me.Panel1.TabIndex = 19
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1, Me.ToolStripStatusLabel2})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 528)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(918, 22)
        Me.StatusStrip1.TabIndex = 25
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.BackColor = System.Drawing.Color.Blue
        Me.ToolStripStatusLabel1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(33, 17)
        Me.ToolStripStatusLabel1.Text = "Time"
        '
        'ToolStripStatusLabel2
        '
        Me.ToolStripStatusLabel2.Name = "ToolStripStatusLabel2"
        Me.ToolStripStatusLabel2.Size = New System.Drawing.Size(119, 17)
        Me.ToolStripStatusLabel2.Text = "ToolStripStatusLabel2"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(734, 267)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(175, 234)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 14
        Me.PictureBox1.TabStop = False
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.SandyBrown
        Me.GroupBox2.Controls.Add(Me.Label9)
        Me.GroupBox2.Controls.Add(Me.lblAll)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.btnOrder)
        Me.GroupBox2.Controls.Add(Me.lblTotal)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Location = New System.Drawing.Point(741, 88)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(158, 133)
        Me.GroupBox2.TabIndex = 17
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Billing"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(144, 53)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(13, 13)
        Me.Label9.TabIndex = 22
        Me.Label9.Text = "$"
        '
        'lblAll
        '
        Me.lblAll.AutoSize = True
        Me.lblAll.Location = New System.Drawing.Point(125, 53)
        Me.lblAll.Name = "lblAll"
        Me.lblAll.Size = New System.Drawing.Size(10, 13)
        Me.lblAll.TabIndex = 21
        Me.lblAll.Text = "-"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(6, 52)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(92, 13)
        Me.Label5.TabIndex = 20
        Me.Label5.Text = "TOTAL ALL DAY:"
        '
        'lblTotal
        '
        Me.lblTotal.AutoSize = True
        Me.lblTotal.Location = New System.Drawing.Point(73, 34)
        Me.lblTotal.Name = "lblTotal"
        Me.lblTotal.Size = New System.Drawing.Size(10, 13)
        Me.lblTotal.TabIndex = 1
        Me.lblTotal.Text = "-"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(7, 34)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(48, 13)
        Me.Label4.TabIndex = 0
        Me.Label4.Text = "TOTAL :"
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.SandyBrown
        Me.Panel2.Font = New System.Drawing.Font("Palatino Linotype", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel2.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Panel2.Location = New System.Drawing.Point(734, 51)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(175, 210)
        Me.Panel2.TabIndex = 22
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(51, 111)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(102, 18)
        Me.Label1.TabIndex = 22
        Me.Label1.Text = "Choose Product"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(58, 111)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(102, 18)
        Me.Label3.TabIndex = 22
        Me.Label3.Text = "Choose Product"
        '
        'Index
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Indigo
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(918, 550)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.carttool)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.lblhello)
        Me.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Name = "Index"
        Me.Text = "Index"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.numday, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.carttool.ResumeLayout(False)
        Me.carttool.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents timerSlide As Timer
    Friend WithEvents iklan As ImageList
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents lblhello As Label
    Friend WithEvents GroupBox5 As GroupBox
    Friend WithEvents cbSpa As CheckBox
    Friend WithEvents cbMassage As CheckBox
    Friend WithEvents cmb3 As ComboBox
    Friend WithEvents cbScrub As CheckBox
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents cbManicure As CheckBox
    Friend WithEvents cbRebound As CheckBox
    Friend WithEvents cmb2 As ComboBox
    Friend WithEvents cbCreambath As CheckBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents Label2 As Label
    Friend WithEvents cbLaser As CheckBox
    Friend WithEvents cbTotok As CheckBox
    Friend WithEvents cbFacial As CheckBox
    Friend WithEvents cmb1 As ComboBox
    Friend WithEvents Label7 As Label
    Friend WithEvents numday As NumericUpDown
    Friend WithEvents clbday As CheckedListBox
    Friend WithEvents MonthCalendar1 As MonthCalendar
    Friend WithEvents carttool As ToolStrip
    Friend WithEvents TsOrder As ToolStripButton
    Friend WithEvents infoorder As ToolTip
    Friend WithEvents infofix As ToolTip
    Friend WithEvents tbexit As ToolStripButton
    Friend WithEvents Panel1 As Panel
    Friend WithEvents StatusStrip1 As StatusStrip
    Friend WithEvents ToolStripStatusLabel1 As ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel2 As ToolStripStatusLabel
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents Label9 As Label
    Friend WithEvents lblAll As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents btnOrder As Button
    Friend WithEvents lblTotal As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Label3 As Label
    Friend WithEvents Label1 As Label
End Class
