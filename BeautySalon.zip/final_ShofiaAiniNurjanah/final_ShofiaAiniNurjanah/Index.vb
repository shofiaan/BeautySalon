﻿Public Class Index


    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles timerSlide.Tick
        Static IM
        IM = IM + 1
        PictureBox1.Image = iklan.Images(IM)
        If IM = 3 Then
            IM = 0
        End If

    End Sub
    Public f1 As Integer = 100
    Public f2 As Integer = 150
    Public f3 As Integer = 200
    Public h1 As Integer = 120
    Public h2 As Integer = 90
    Public h3 As Integer = 95
    Public b1 As Integer = 200
    Public b2 As Integer = 220
    Public b3 As Integer = 180

    Private Sub BtnOrder_Click(sender As Object, e As EventArgs) Handles btnOrder.Click
        Dim subtotal(9, 3) As String 'multi dimensional array'
        Dim subtotalItem As ListViewItem
        Dim i As Integer
        Dim hasil As Integer
        hasil = 0
        i = 0
        If cbFacial.Checked = True Then
            subtotal(i, 0) = i + 1
            subtotal(i, 1) = cbFacial.Text
            subtotal(i, 2) = f1
            hasil = hasil + f1
            i = i + 1
        End If
        If cbTotok.Checked = True Then
            subtotal(i, 0) = i + 1
            subtotal(i, 1) = cbTotok.Text
            subtotal(i, 2) = f2
            hasil = hasil + f2
            i = i + 1
        End If
        If cbLaser.Checked = True Then
            subtotal(i, 0) = i + 1
            subtotal(i, 1) = cbLaser.Text
            subtotal(i, 2) = f3
            hasil = hasil + f3
            i = i + 1
        End If
        If cbCreambath.Checked = True Then
            subtotal(i, 0) = i + 1
            subtotal(i, 1) = cbCreambath.Text
            subtotal(i, 2) = h1
            hasil = hasil + h1
            i = i + 1
        End If
        If cbRebound.Checked = True Then
            subtotal(i, 0) = i + 1
            subtotal(i, 1) = cbRebound.Text
            subtotal(i, 2) = h2
            hasil = hasil + h2
            i = i + 1
        End If
        If cbManicure.Checked = True Then
            subtotal(i, 0) = i + 1
            subtotal(i, 1) = cbManicure.Text
            subtotal(i, 2) = h3
            hasil = hasil + h3
            i = i + 1
        End If
        If cbMassage.Checked = True Then
            subtotal(i, 0) = i + 1
            subtotal(i, 1) = cbMassage.Text
            subtotal(i, 2) = b1
            hasil = hasil + b1
            i = i + 1
        End If
        If cbScrub.Checked = True Then
            subtotal(i, 0) = i + 1
            subtotal(i, 1) = cbScrub.Text
            subtotal(i, 2) = b2
            hasil = hasil + b2
            i = i + 1
        End If
        If cbSpa.Checked = True Then
            subtotal(i, 0) = i + 1
            subtotal(i, 1) = cbSpa.Text
            subtotal(i, 2) = b3
            hasil = hasil + b3
            i = i + 1
        End If
        Dim j, k As Integer
        Dim arr(3) As String
        For j = 0 To i - 1 'nested loop j baris k kolom'
            For k = 0 To 2
                arr(k) = subtotal(j, k)
            Next

            subtotalItem = New ListViewItem(arr)
            bill.ListView1.Items.Add(subtotalItem)
        Next
        bill.ListBox1.Items.Add("Your Face Treatment is  " & cmb1.Text)
        bill.ListBox1.Items.Add("Your Hair Treatment is  " & cmb2.Text)
        bill.ListBox1.Items.Add("Your Body Treatment is  " & cmb3.Text & vbCrLf)

        bill.ListBox1.Items.Add("Total Payment  " & lblTotal.Text)
        bill.ListBox1.Items.Add("Total All day Payment  " & lblAll.Text & "$")

        bill.Show()

    End Sub

    Private Sub TsOrder_Click_1(sender As Object, e As EventArgs) Handles TsOrder.Click

        Dim sum As Integer
        If cbFacial.Checked = True Then
            sum += f1
        End If
        If cbTotok.Checked = True Then
            sum += f2
        End If
        If cbLaser.Checked = True Then
            sum += f3
        End If
        If cbCreambath.Checked = True Then
            sum += h1
        End If
        If cbRebound.Checked = True Then
            sum += h2
        End If
        If cbManicure.Checked = True Then
            sum += h3
        End If
        If cbMassage.Checked = True Then
            sum += b1
        End If
        If cbScrub.Checked = True Then
            sum += b2
        End If
        If cbSpa.Checked = True Then
            sum += b3
        End If
        lblTotal.Text = sum.ToString("C")

        bill.ListBox1.Items.Add("The day you've Chosen: ")
        For intcount As Integer = 0 To clbday.Items.Count - 1
            If clbday.GetItemChecked(intcount) Then
                bill.ListBox1.Items.Add(clbday.Items(intcount))
            End If
        Next
        Dim Day = numday.Value
        'procedure function'
        'bikin conditional sesuai hari misal 3 jadi bisa 3 doang yang di check
        lblAll.Text = Day * lblTotal.Text

    End Sub

    Private Sub Index_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ToolStripStatusLabel1.Text = TimeOfDay
    End Sub


End Class