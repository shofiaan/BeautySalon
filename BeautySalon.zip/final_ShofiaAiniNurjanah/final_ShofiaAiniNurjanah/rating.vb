﻿Public Class rating
    Private Sub VScrollBar1_Scroll(sender As Object, e As ScrollEventArgs) Handles VScrollBar1.Scroll
        If VScrollBar1.Value < 35 Then
            star.Text = "Excellent"
        ElseIf VScrollBar1.Value > 35 And VScrollBar1.Value < 65 Then
            star.Text = "Quite Good"
        ElseIf VScrollBar1.Value > 65 And VScrollBar1.Value < 80 Then
            star.Text = "BAD"
        Else
            star.Text = "Really Really Bad"
        End If
    End Sub

End Class