﻿Public Class welcome

    Private Sub SignInToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SignInToolStripMenuItem.Click
        Dim MDIChild As New login()
        MDIChild.MdiParent = Me
        MDIChild.Show()
        Application.DoEvents()
        MDIChild.Location = New Point(Me.Width / 2 - MDIChild.Width / 2, Me.Height / 2 - MDIChild.Height / 2)
    End Sub

    Private Sub RegisterToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RegisterToolStripMenuItem.Click
        Regist.Show()
        Me.Hide()
    End Sub

    Private Sub RegisterToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles RegisterToolStripMenuItem1.Click
        Regist.Show()
        Me.Hide()
    End Sub

    Private Sub SignInToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles SignInToolStripMenuItem1.Click
        Dim MDIChild As New login()
        MDIChild.MdiParent = Me
        MDIChild.Show()
        Application.DoEvents()
        MDIChild.Location = New Point(Me.Width / 2 - MDIChild.Width / 2, Me.Height / 2 - MDIChild.Height / 2)
    End Sub

    Private Sub OrderToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OrderToolStripMenuItem.Click
        MsgBox("You have to sign in first")
    End Sub

    Private Sub CloseToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CloseToolStripMenuItem.Click
        Me.Close()
    End Sub

    Private Sub Welcome_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class