﻿Imports MySql.Data.MySqlClient
Public Class Regist
    Dim MysqlConn As MySqlConnection
    Dim COMMAND As MySqlCommand

    Dim gender_arr() = {"Male", "Female"}
    Dim gender As String

    Private Sub clear_entry()
        txtName.Text = ""
        rdbmale.Checked = False
        rdbfem.Checked = False
        txtadd.Text = ""
        txtPhn.Text = ""
        txtUss.Text = ""
        txtPin.Text = ""
        txtRe.Text = ""
    End Sub

    Private Sub BtnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        clear_entry()
    End Sub

    Private Sub RegisterBtn_Click(sender As Object, e As EventArgs) Handles registerBtn.Click

        If rdbmale.Checked = True Then
            gender = gender_arr(0)
        ElseIf rdbfem.Checked = True Then
            gender = gender_arr(1)
        End If

        MysqlConn = New MySqlConnection
        MysqlConn.ConnectionString = "server=localhost; userid=root; password=''; database=database_vb"
        Dim READER As MySqlDataReader

        Try
            MysqlConn.Open()

            Dim Query As String
            Query = "INSERT INTO user(user_name, user_dob ,  user_gender, user_address, user_phone, user_uss, user_pin)
                    VALUES('" & txtName.Text & "', '" & dtp.Text & "' , '" & gender & "', '" & txtadd.Text & "', '" & txtPhn.Text & "', '" & txtUss.Text & "', '" & txtPin.Text & "')"
            COMMAND = New MySqlCommand(Query, MysqlConn) 'Special variable to store current query and connection
            If txtPin.Text = txtRe.Text Then
                READER = COMMAND.ExecuteReader  'To execute the query
                MessageBox.Show("Data Inserted Successfully")
                clear_entry()
                Me.TabControl1.SelectedIndex = 1
            Else
                MessageBox.Show("Pin are not match")
            End If

            MysqlConn.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message)

        Finally
            MysqlConn.Dispose()

        End Try

    End Sub

    Private Sub LoadBtn_Click(sender As Object, e As EventArgs) Handles loadBtn.Click
        MysqlConn = New MySqlConnection
        MysqlConn.ConnectionString = "server=localhost; userid=root; password=''; database=database_vb"
        Dim SDA As New MySqlDataAdapter 'translate to table
        Dim dbDataSet As New DataTable 'nyimpen data
        Dim bSource As New BindingSource

        Try
            MysqlConn.Open()
            Dim Query As String
            Query = "SELECT * FROM user"
            COMMAND = New MySqlCommand(Query, MysqlConn)
            SDA.SelectCommand = COMMAND
            SDA.Fill(dbDataSet)
            bSource.DataSource = dbDataSet
            DataGridView1.DataSource = bSource
            SDA.Update(dbDataSet)
            MysqlConn.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message)

        Finally
            MysqlConn.Dispose()

        End Try
    End Sub

    Private Sub BtnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click

        MysqlConn = New MySqlConnection
        MysqlConn.ConnectionString = "server=localhost; userid=root; password=''; database=database_vb"
        Dim READER As MySqlDataReader
        Try
            MysqlConn.Open()
            Dim Query As String
            Query = "DELETE FROM user WHERE user_id = '" & updateIdTextView.Text & "'"
            COMMAND = New MySqlCommand(Query, MysqlConn)
            READER = COMMAND.ExecuteReader

            MessageBox.Show("Data Deleted")
            MysqlConn.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            MysqlConn.Dispose()
        End Try
    End Sub

    Private Sub BtnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        MysqlConn = New MySqlConnection
        MysqlConn.ConnectionString = "server=localhost; userid=root; password=''; database=database_vb"
        Dim READER As MySqlDataReader
        Try
            MysqlConn.Open()
            Dim Query As String
            Query = "UPDATE user SET user_name='" & updateNameTextView.Text & "', user_address='" & updateAddressTextView.Text & "', user_phone='" & updatePhoneTextView.Text & "'
                    WHERE user_id='" & updateIdTextView.Text & "'"
            COMMAND = New MySqlCommand(Query, MysqlConn)
            READER = COMMAND.ExecuteReader
            MessageBox.Show("Data Updated")
            MysqlConn.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            MysqlConn.Dispose()
        End Try
    End Sub

    Private Sub Rdbfem_CheckedChanged(sender As Object, e As EventArgs) Handles rdbfem.CheckedChanged

    End Sub
End Class
