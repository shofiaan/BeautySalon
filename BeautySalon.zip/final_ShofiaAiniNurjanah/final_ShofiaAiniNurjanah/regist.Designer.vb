﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Regist
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Regist))
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.txtUss = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.rdbfem = New System.Windows.Forms.RadioButton()
        Me.rdbmale = New System.Windows.Forms.RadioButton()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.registerBtn = New System.Windows.Forms.Button()
        Me.txtPin = New System.Windows.Forms.MaskedTextBox()
        Me.txtRe = New System.Windows.Forms.MaskedTextBox()
        Me.dtp = New System.Windows.Forms.DateTimePicker()
        Me.txtPhn = New System.Windows.Forms.TextBox()
        Me.txtadd = New System.Windows.Forms.TextBox()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.updatePhoneTextView = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.updateAddressTextView = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.updateNameTextView = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.updateIdTextView = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.loadBtn = New System.Windows.Forms.Button()
        Me.btnUpdate = New System.Windows.Forms.Button()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Location = New System.Drawing.Point(14, 15)
        Me.TabControl1.Margin = New System.Windows.Forms.Padding(4)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(869, 517)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.SplitContainer1)
        Me.TabPage1.Controls.Add(Me.Label8)
        Me.TabPage1.Location = New System.Drawing.Point(4, 25)
        Me.TabPage1.Margin = New System.Windows.Forms.Padding(4)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(4)
        Me.TabPage1.Size = New System.Drawing.Size(861, 488)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Register"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.Location = New System.Drawing.Point(4, 4)
        Me.SplitContainer1.Margin = New System.Windows.Forms.Padding(4)
        Me.SplitContainer1.Name = "SplitContainer1"
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.BackColor = System.Drawing.Color.Peru
        Me.SplitContainer1.Panel1.BackgroundImage = CType(resources.GetObject("SplitContainer1.Panel1.BackgroundImage"), System.Drawing.Image)
        Me.SplitContainer1.Panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.BackColor = System.Drawing.Color.Chocolate
        Me.SplitContainer1.Panel2.Controls.Add(Me.txtUss)
        Me.SplitContainer1.Panel2.Controls.Add(Me.Label14)
        Me.SplitContainer1.Panel2.Controls.Add(Me.btnClear)
        Me.SplitContainer1.Panel2.Controls.Add(Me.Label9)
        Me.SplitContainer1.Panel2.Controls.Add(Me.Label3)
        Me.SplitContainer1.Panel2.Controls.Add(Me.rdbfem)
        Me.SplitContainer1.Panel2.Controls.Add(Me.rdbmale)
        Me.SplitContainer1.Panel2.Controls.Add(Me.Label7)
        Me.SplitContainer1.Panel2.Controls.Add(Me.Label6)
        Me.SplitContainer1.Panel2.Controls.Add(Me.Label5)
        Me.SplitContainer1.Panel2.Controls.Add(Me.Label4)
        Me.SplitContainer1.Panel2.Controls.Add(Me.Label2)
        Me.SplitContainer1.Panel2.Controls.Add(Me.Label1)
        Me.SplitContainer1.Panel2.Controls.Add(Me.registerBtn)
        Me.SplitContainer1.Panel2.Controls.Add(Me.txtPin)
        Me.SplitContainer1.Panel2.Controls.Add(Me.txtRe)
        Me.SplitContainer1.Panel2.Controls.Add(Me.dtp)
        Me.SplitContainer1.Panel2.Controls.Add(Me.txtPhn)
        Me.SplitContainer1.Panel2.Controls.Add(Me.txtadd)
        Me.SplitContainer1.Panel2.Controls.Add(Me.txtName)
        Me.SplitContainer1.Size = New System.Drawing.Size(853, 480)
        Me.SplitContainer1.SplitterDistance = 282
        Me.SplitContainer1.TabIndex = 16
        '
        'txtUss
        '
        Me.txtUss.Location = New System.Drawing.Point(174, 287)
        Me.txtUss.Margin = New System.Windows.Forms.Padding(4)
        Me.txtUss.Name = "txtUss"
        Me.txtUss.Size = New System.Drawing.Size(350, 23)
        Me.txtUss.TabIndex = 38
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(39, 290)
        Me.Label14.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(124, 16)
        Me.Label14.TabIndex = 37
        Me.Label14.Text = "Choose USERNAME"
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(43, 380)
        Me.btnClear.Margin = New System.Windows.Forms.Padding(4)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(88, 28)
        Me.btnClear.TabIndex = 35
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Rockwell", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(24, 33)
        Me.Label9.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(96, 21)
        Me.Label9.TabIndex = 2
        Me.Label9.Text = "User Data"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(39, 145)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(52, 16)
        Me.Label3.TabIndex = 34
        Me.Label3.Text = "Gender"
        '
        'rdbfem
        '
        Me.rdbfem.AutoSize = True
        Me.rdbfem.Location = New System.Drawing.Point(237, 143)
        Me.rdbfem.Margin = New System.Windows.Forms.Padding(4)
        Me.rdbfem.Name = "rdbfem"
        Me.rdbfem.Size = New System.Drawing.Size(68, 20)
        Me.rdbfem.TabIndex = 33
        Me.rdbfem.TabStop = True
        Me.rdbfem.Text = "Female"
        Me.rdbfem.UseVisualStyleBackColor = True
        '
        'rdbmale
        '
        Me.rdbmale.AutoSize = True
        Me.rdbmale.Location = New System.Drawing.Point(174, 143)
        Me.rdbmale.Margin = New System.Windows.Forms.Padding(4)
        Me.rdbmale.Name = "rdbmale"
        Me.rdbmale.Size = New System.Drawing.Size(54, 20)
        Me.rdbmale.TabIndex = 32
        Me.rdbmale.TabStop = True
        Me.rdbmale.Text = "Male"
        Me.rdbmale.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(39, 349)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(82, 16)
        Me.Label7.TabIndex = 31
        Me.Label7.Text = "Re-Enter PIN"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(40, 318)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(28, 16)
        Me.Label6.TabIndex = 30
        Me.Label6.Text = "PIN"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(39, 262)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(93, 16)
        Me.Label5.TabIndex = 29
        Me.Label5.Text = "Phone Number"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(39, 180)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(57, 16)
        Me.Label4.TabIndex = 28
        Me.Label4.Text = "Address"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(39, 115)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(79, 16)
        Me.Label2.TabIndex = 27
        Me.Label2.Text = "Date of Birth"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(39, 77)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(42, 16)
        Me.Label1.TabIndex = 26
        Me.Label1.Text = "Name"
        '
        'registerBtn
        '
        Me.registerBtn.Location = New System.Drawing.Point(438, 380)
        Me.registerBtn.Margin = New System.Windows.Forms.Padding(4)
        Me.registerBtn.Name = "registerBtn"
        Me.registerBtn.Size = New System.Drawing.Size(88, 28)
        Me.registerBtn.TabIndex = 25
        Me.registerBtn.Text = "Register"
        Me.registerBtn.UseVisualStyleBackColor = True
        '
        'txtPin
        '
        Me.txtPin.Location = New System.Drawing.Point(174, 318)
        Me.txtPin.Margin = New System.Windows.Forms.Padding(4)
        Me.txtPin.Name = "txtPin"
        Me.txtPin.Size = New System.Drawing.Size(350, 23)
        Me.txtPin.TabIndex = 24
        '
        'txtRe
        '
        Me.txtRe.Location = New System.Drawing.Point(174, 349)
        Me.txtRe.Margin = New System.Windows.Forms.Padding(4)
        Me.txtRe.Name = "txtRe"
        Me.txtRe.Size = New System.Drawing.Size(350, 23)
        Me.txtRe.TabIndex = 23
        '
        'dtp
        '
        Me.dtp.CustomFormat = "yyyy-MM-dd"
        Me.dtp.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtp.Location = New System.Drawing.Point(174, 107)
        Me.dtp.Margin = New System.Windows.Forms.Padding(4)
        Me.dtp.Name = "dtp"
        Me.dtp.Size = New System.Drawing.Size(350, 23)
        Me.dtp.TabIndex = 22
        '
        'txtPhn
        '
        Me.txtPhn.Location = New System.Drawing.Point(174, 259)
        Me.txtPhn.Margin = New System.Windows.Forms.Padding(4)
        Me.txtPhn.Name = "txtPhn"
        Me.txtPhn.Size = New System.Drawing.Size(350, 23)
        Me.txtPhn.TabIndex = 21
        '
        'txtadd
        '
        Me.txtadd.Location = New System.Drawing.Point(174, 176)
        Me.txtadd.Margin = New System.Windows.Forms.Padding(4)
        Me.txtadd.Multiline = True
        Me.txtadd.Name = "txtadd"
        Me.txtadd.Size = New System.Drawing.Size(350, 74)
        Me.txtadd.TabIndex = 20
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(174, 74)
        Me.txtName.Margin = New System.Windows.Forms.Padding(4)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(350, 23)
        Me.txtName.TabIndex = 19
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(32, 21)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(0, 16)
        Me.Label8.TabIndex = 15
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.Color.Chocolate
        Me.TabPage2.Controls.Add(Me.updatePhoneTextView)
        Me.TabPage2.Controls.Add(Me.Label13)
        Me.TabPage2.Controls.Add(Me.updateAddressTextView)
        Me.TabPage2.Controls.Add(Me.Label12)
        Me.TabPage2.Controls.Add(Me.updateNameTextView)
        Me.TabPage2.Controls.Add(Me.Label11)
        Me.TabPage2.Controls.Add(Me.updateIdTextView)
        Me.TabPage2.Controls.Add(Me.Label10)
        Me.TabPage2.Controls.Add(Me.loadBtn)
        Me.TabPage2.Controls.Add(Me.btnUpdate)
        Me.TabPage2.Controls.Add(Me.btnDelete)
        Me.TabPage2.Controls.Add(Me.DataGridView1)
        Me.TabPage2.Location = New System.Drawing.Point(4, 25)
        Me.TabPage2.Margin = New System.Windows.Forms.Padding(4)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(4)
        Me.TabPage2.Size = New System.Drawing.Size(861, 488)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Record"
        '
        'updatePhoneTextView
        '
        Me.updatePhoneTextView.Location = New System.Drawing.Point(119, 360)
        Me.updatePhoneTextView.Margin = New System.Windows.Forms.Padding(4)
        Me.updatePhoneTextView.Name = "updatePhoneTextView"
        Me.updatePhoneTextView.Size = New System.Drawing.Size(116, 23)
        Me.updatePhoneTextView.TabIndex = 12
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(18, 364)
        Me.Label13.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(97, 16)
        Me.Label13.TabIndex = 11
        Me.Label13.Text = "Phone Number:"
        '
        'updateAddressTextView
        '
        Me.updateAddressTextView.Location = New System.Drawing.Point(119, 289)
        Me.updateAddressTextView.Margin = New System.Windows.Forms.Padding(4)
        Me.updateAddressTextView.Multiline = True
        Me.updateAddressTextView.Name = "updateAddressTextView"
        Me.updateAddressTextView.Size = New System.Drawing.Size(304, 62)
        Me.updateAddressTextView.TabIndex = 10
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(18, 293)
        Me.Label12.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(61, 16)
        Me.Label12.TabIndex = 9
        Me.Label12.Text = "Address:"
        '
        'updateNameTextView
        '
        Me.updateNameTextView.Location = New System.Drawing.Point(119, 257)
        Me.updateNameTextView.Margin = New System.Windows.Forms.Padding(4)
        Me.updateNameTextView.Name = "updateNameTextView"
        Me.updateNameTextView.Size = New System.Drawing.Size(116, 23)
        Me.updateNameTextView.TabIndex = 8
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(18, 261)
        Me.Label11.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(46, 16)
        Me.Label11.TabIndex = 7
        Me.Label11.Text = "Name:"
        '
        'updateIdTextView
        '
        Me.updateIdTextView.Location = New System.Drawing.Point(119, 225)
        Me.updateIdTextView.Margin = New System.Windows.Forms.Padding(4)
        Me.updateIdTextView.Name = "updateIdTextView"
        Me.updateIdTextView.Size = New System.Drawing.Size(116, 23)
        Me.updateIdTextView.TabIndex = 6
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(18, 229)
        Me.Label10.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(24, 16)
        Me.Label10.TabIndex = 5
        Me.Label10.Text = "Id:"
        '
        'loadBtn
        '
        Me.loadBtn.Location = New System.Drawing.Point(731, 19)
        Me.loadBtn.Margin = New System.Windows.Forms.Padding(4)
        Me.loadBtn.Name = "loadBtn"
        Me.loadBtn.Size = New System.Drawing.Size(122, 43)
        Me.loadBtn.TabIndex = 4
        Me.loadBtn.Text = "Load Table"
        Me.loadBtn.UseVisualStyleBackColor = True
        '
        'btnUpdate
        '
        Me.btnUpdate.Location = New System.Drawing.Point(132, 401)
        Me.btnUpdate.Margin = New System.Windows.Forms.Padding(4)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(88, 28)
        Me.btnUpdate.TabIndex = 3
        Me.btnUpdate.Text = "Update"
        Me.btnUpdate.UseVisualStyleBackColor = True
        '
        'btnDelete
        '
        Me.btnDelete.Location = New System.Drawing.Point(21, 401)
        Me.btnDelete.Margin = New System.Windows.Forms.Padding(4)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(88, 28)
        Me.btnDelete.TabIndex = 2
        Me.btnDelete.Text = "Delete"
        Me.btnDelete.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.BackgroundColor = System.Drawing.Color.Coral
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.GridColor = System.Drawing.Color.SandyBrown
        Me.DataGridView1.Location = New System.Drawing.Point(8, 19)
        Me.DataGridView1.Margin = New System.Windows.Forms.Padding(4)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(715, 184)
        Me.DataGridView1.TabIndex = 0
        '
        'Regist
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(892, 479)
        Me.Controls.Add(Me.TabControl1)
        Me.Font = New System.Drawing.Font("Rockwell", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "Regist"
        Me.Text = "Registration"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        Me.SplitContainer1.Panel2.PerformLayout()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents Label8 As Label
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents SplitContainer1 As SplitContainer
    Friend WithEvents Label9 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents rdbfem As RadioButton
    Friend WithEvents rdbmale As RadioButton
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents registerBtn As Button
    Friend WithEvents txtPin As MaskedTextBox
    Friend WithEvents txtRe As MaskedTextBox
    Friend WithEvents dtp As DateTimePicker
    Friend WithEvents txtPhn As TextBox
    Friend WithEvents txtadd As TextBox
    Friend WithEvents txtName As TextBox
    Friend WithEvents btnClear As Button
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents btnUpdate As Button
    Friend WithEvents btnDelete As Button
    Friend WithEvents loadBtn As Button
    Friend WithEvents updateIdTextView As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents updateNameTextView As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents updatePhoneTextView As TextBox
    Friend WithEvents Label13 As Label
    Friend WithEvents updateAddressTextView As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents txtUss As TextBox
End Class
