﻿Imports MySql.Data.MySqlClient
Public Class login

    Private connection As New MySqlConnection("server=localhost; userid=root; password=''; database=database_vb")

    ' return the connection
    ReadOnly Property getConnection() As MySqlConnection
        Get
            Return connection
        End Get
    End Property

    ' open the connection
    Sub openConnection()

        If connection.State = ConnectionState.Closed Then
            connection.Open()
        End If

    End Sub

    ' close the connection
    Sub closeConnection()

        If connection.State = ConnectionState.Open Then
            connection.Close()
        End If

    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Regist.Show()
    End Sub
    Private Sub BtnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click


        Dim adapter As New MySqlDataAdapter()
        Dim table As New DataTable()
        Dim command As New MySqlCommand("SELECT `user_uss`, `user_pin` FROM `user` WHERE `user_uss` = @usn AND `user_pin` = @pass", getConnection())

        command.Parameters.Add("@usn", MySqlDbType.VarChar).Value = txtUser.Text
        command.Parameters.Add("@pass", MySqlDbType.VarChar).Value = txtPas.Text

        Dim greet As String
        greet = hello()

        If txtUser.Text = "" Then
            Loading.Start()
            MsgBox(greet)
        ElseIf txtPas.Text = "" Then
            Loading.Start()
            MsgBox(greet)
        Else
            Loading.Start()

            adapter.SelectCommand = command
            adapter.Fill(table)

            If table.Rows.Count > 0 Then
                Index.MdiParent = welcome
                Index.Show()

            Else

                MsgBox("Username or Password doesnt Exsist")

            End If

        End If
    End Sub

    Function hello() As String
        Dim grt As String = "Don't leave the box empty.!"
        Return grt
    End Function

    Private Sub Loading_Tick(sender As Object, e As EventArgs) Handles Loading.Tick
        pb1.Increment(10)
    End Sub

    Private Sub Login_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class